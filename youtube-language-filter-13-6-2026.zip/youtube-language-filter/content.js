'use strict';

// ISO 639-1 codes. YouTube API returns BCP-47; CLD returns its own subset.
const LANGUAGES = [
  { code: '',      label: 'All Languages' },
  { code: 'ar',    label: 'Arabic' },
  { code: 'bn',    label: 'Bengali' },
  { code: 'zh-CN', label: 'Chinese (Simplified)' },
  { code: 'zh-TW', label: 'Chinese (Traditional)' },
  { code: 'cs',    label: 'Czech' },
  { code: 'da',    label: 'Danish' },
  { code: 'nl',    label: 'Dutch' },
  { code: 'en',    label: 'English' },
  { code: 'fi',    label: 'Finnish' },
  { code: 'fr',    label: 'French' },
  { code: 'de',    label: 'German' },
  { code: 'el',    label: 'Greek' },
  { code: 'gu',    label: 'Gujarati' },
  { code: 'he',    label: 'Hebrew' },
  { code: 'hi',    label: 'Hindi' },
  { code: 'hu',    label: 'Hungarian' },
  { code: 'id',    label: 'Indonesian' },
  { code: 'it',    label: 'Italian' },
  { code: 'ja',    label: 'Japanese' },
  { code: 'kn',    label: 'Kannada' },
  { code: 'ko',    label: 'Korean' },
  { code: 'ms',    label: 'Malay' },
  { code: 'ml',    label: 'Malayalam' },
  { code: 'mr',    label: 'Marathi' },
  { code: 'no',    label: 'Norwegian' },
  { code: 'fa',    label: 'Persian' },
  { code: 'pl',    label: 'Polish' },
  { code: 'pt',    label: 'Portuguese' },
  { code: 'pa',    label: 'Punjabi' },
  { code: 'ro',    label: 'Romanian' },
  { code: 'ru',    label: 'Russian' },
  { code: 'sk',    label: 'Slovak' },
  { code: 'es',    label: 'Spanish' },
  { code: 'sv',    label: 'Swedish' },
  { code: 'ta',    label: 'Tamil' },
  { code: 'te',    label: 'Telugu' },
  { code: 'th',    label: 'Thai' },
  { code: 'tr',    label: 'Turkish' },
  { code: 'uk',    label: 'Ukrainian' },
  { code: 'ur',    label: 'Urdu' },
  { code: 'vi',    label: 'Vietnamese' },
];

// Quiet diagnostic logging — console only, filter by "YTLF" in DevTools.
// No on-page UI: the extension must leave no visible trace of itself.
function ytlfLog(msg) {
  console.log(`[YTLF] ${msg}`);
}

const LANG_KEY          = 'ytlf_lang';
const API_KEY           = 'ytlf_api_key';
const HIDE_HOME_KEY      = 'ytlf_hide_home';
const HIDE_SIDEBAR_KEY   = 'ytlf_hide_sidebar';
const HIDE_SHORTS_KEY    = 'ytlf_hide_shorts';
const HIDE_ENGAGEMENTS_KEY = 'ytlf_hide_engagements';
const ENABLED_KEY        = 'ytlf_enabled';
const MIN_TEXT_LEN = 12;   // CLD needs enough chars to be confident
const MIN_CONF     = 55;   // below this % we show the video rather than wrongly hide it
const BATCH_MS     = 50;   // debounce window to collect IDs before one API call
const THEME_KEY    = 'ytlf_theme'; // 'light' | 'dark' | absent = follow YouTube

// All YouTube renderer types we filter:
// ytd-video-renderer       → search results
// ytd-compact-video-renderer → watch page sidebar / Up Next
// ytd-rich-item-renderer   → homepage grid & subscription feed
const RENDERER_SEL = 'ytd-video-renderer, ytd-compact-video-renderer, ytd-rich-item-renderer';

// --- API key + display toggles: cached in memory, kept fresh via storage.onChanged ---

let cachedApiKey  = null;
let hideHome      = false;
let hideSidebar   = false;
let hideShorts    = false;
let hideEngagements = false;
let enabled       = true;   // master on/off switch

chrome.storage.sync.get(
  [API_KEY, HIDE_HOME_KEY, HIDE_SIDEBAR_KEY, HIDE_SHORTS_KEY, HIDE_ENGAGEMENTS_KEY, ENABLED_KEY],
  (res) => {
    cachedApiKey    = res[API_KEY] || null;
    hideHome        = !!res[HIDE_HOME_KEY];
    hideSidebar     = !!res[HIDE_SIDEBAR_KEY];
    hideShorts      = !!res[HIDE_SHORTS_KEY];
    hideEngagements = !!res[HIDE_ENGAGEMENTS_KEY];
    enabled       = res[ENABLED_KEY] !== false; // default on
    applyDisplayToggles();
  }
);

chrome.storage.onChanged.addListener((changes) => {
  if (changes[API_KEY]) {
    cachedApiKey = changes[API_KEY].newValue || null;
    if (enabled) filterAll();
  }
  if (changes[HIDE_HOME_KEY]) {
    hideHome = !!changes[HIDE_HOME_KEY].newValue;
    applyDisplayToggles();
  }
  if (changes[HIDE_SIDEBAR_KEY]) {
    hideSidebar = !!changes[HIDE_SIDEBAR_KEY].newValue;
    applyDisplayToggles();
  }
  if (changes[HIDE_SHORTS_KEY]) {
    hideShorts = !!changes[HIDE_SHORTS_KEY].newValue;
    applyDisplayToggles();
  }
  if (changes[HIDE_ENGAGEMENTS_KEY]) {
    hideEngagements = !!changes[HIDE_ENGAGEMENTS_KEY].newValue;
    applyDisplayToggles();
  }
  if (changes[ENABLED_KEY]) {
    enabled = changes[ENABLED_KEY].newValue !== false;
    // Sync widget opacity
    const w = document.getElementById('ytlf');
    if (w) w.dataset.enabled = enabled ? '1' : '0';
    if (!enabled) {
      // Show all videos, remove all CSS classes
      document.querySelectorAll(RENDERER_SEL).forEach(r => { r.style.display = ''; });
      applyDisplayToggles();
    } else {
      injectWidget();
      applyDisplayToggles();
      if (isFilteredPage()) filterAll();
    }
  }
});

// Tag Shorts elements with data-ytlf-shorts so CSS can hide them.
// Uses title-text matching as the primary strategy — works regardless of what
// element name YouTube uses. Also covers known element types and /shorts/ links.
// Set a data-attribute only when it would actually change. Writing dataset
// unconditionally fires a MutationObserver record even when the value is
// unchanged, which would feed our own observer in a loop. mark() makes the
// tagging idempotent and feedback-free.
function mark(el, prop) {
  if (el && el.dataset[prop] !== '1') el.dataset[prop] = '1';
}

// The element it is SAFE to hide for a given shorts element. The hard rule: never
// hide a search-results section that also holds real videos. On /results the whole
// results list — reel shelf included — lives in ONE ytd-item-section-renderer, so
// hiding that section empties the list and throws YouTube's infinite scroll into a
// continuous refresh loop. Homepage shorts sit in a dedicated rich wrapper (safe to
// hide whole); a search reel shelf in a mixed section → hide just the shelf; a
// section that is purely shorts → hide the section.
function shortsHideTarget(el) {
  const rich = el.closest('ytd-rich-section-renderer, ytd-rich-item-renderer');
  if (rich) return rich;
  const section = el.closest('ytd-item-section-renderer');
  if (section && !section.querySelector('ytd-video-renderer')) return section;
  return el;
}

// Horizontal "shelf" wrappers YouTube groups content in. A Shorts shelf can be ANY
// of these with a TOPIC title (e.g. "Baking") and the Shorts icon — not the word
// "Shorts", and not always ytd-reel-shelf-renderer (newer ones are view-models) —
// so we detect a shelf by the shorts content inside it. Deliberately EXCLUDES
// ytd-item-section-renderer: the main vertical results live there and must never
// be taken down as a unit.
const SHORTS_SHELF_SEL =
  'ytd-reel-shelf-renderer, ytd-rich-shelf-renderer, ytd-shelf-renderer, ' +
  'grid-shelf-view-model, ytd-horizontal-card-list-renderer, yt-horizontal-list-renderer';

// `node` is known to BE shorts (a /shorts/ link, a shorts lockup, a SHORTS overlay).
// Hide the whole enclosing shorts shelf when there is one; else the single card;
// else the nearest safe container. shortsHideTarget guarantees we never hide a
// section that still holds real vertical results.
function hideShortsContent(node) {
  const shelf = node.closest(SHORTS_SHELF_SEL);
  if (shelf) { mark(shortsHideTarget(shelf), 'ytlfShorts'); return; }
  const card = node.closest(
    'ytd-rich-item-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer, ' +
    'ytd-video-renderer, ytd-reel-item-renderer, ' +
    'yt-shorts-lockup-view-model, ytm-shorts-lockup-view-model'
  );
  mark(card ?? shortsHideTarget(node), 'ytlfShorts');
}

let shortsTagTimer = null;
function tagShorts() {
  // A section tagged while it was shorts-only but that has since gained real video
  // results must be un-tagged, or the stale tag keeps the new results hidden.
  document.querySelectorAll('ytd-item-section-renderer[data-ytlf-shorts]').forEach(sec => {
    if (sec.querySelector('ytd-video-renderer')) delete sec.dataset.ytlfShorts;
  });
  // Known shorts element types/attributes — hide each via its safe target.
  for (const sel of [
    'ytd-reel-shelf-renderer', 'ytd-rich-shelf-renderer[is-shorts]',
    'ytd-shelf-renderer[is-shorts]', 'ytd-reel-item-renderer',
    'ytd-shorts', 'yt-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model',
  ]) {
    document.querySelectorAll(sel).forEach(el => mark(shortsHideTarget(el), 'ytlfShorts'));
  }
  // Shorts CONTENT anywhere — the robust catch. /shorts/ links cover topic-titled
  // view-model shelves (e.g. "🩳 Baking") and individual short cards; the SHORTS
  // thumbnail overlay and [is-shorts] catch shorts whose element type we don't know.
  document.querySelectorAll(
    'a[href^="/shorts/"], [overlay-style="SHORTS"], [is-shorts]'
  ).forEach(hideShortsContent);
  // Dedicated shelves YouTube labels "Shorts" by header text (unknown element types).
  document.querySelectorAll(SHORTS_SHELF_SEL).forEach(shelf => {
    const text = shelf.querySelector('#title, h2, #header-text, .title, #title-text')?.textContent ?? '';
    if (/shorts/i.test(text)) mark(shortsHideTarget(shelf), 'ytlfShorts');
  });
}

// Tag Playables elements similarly
function tagPlayables() {
  for (const sel of ['ytd-game-card-renderer']) {
    document.querySelectorAll(sel).forEach(el => {
      mark(el.closest('ytd-rich-section-renderer, ytd-rich-item-renderer') ?? el, 'ytlfPlayables');
    });
  }
  document.querySelectorAll('ytd-rich-section-renderer').forEach(sec => {
    const text = sec.querySelector('#title, h2, yt-formatted-string')?.textContent ?? '';
    if (/playable/i.test(text)) mark(sec, 'ytlfPlayables');
  });
}

// Selectors for elements that count as "engagements" (view counts, likes, etc.)
const ENGAGEMENT_SELS = [
  '#metadata-line',
  'span.inline-metadata-item',
  'ytd-video-view-count-renderer',
  'yt-view-count-renderer',
  'ytd-watch-info-text',
  'segmented-like-dislike-button-view-model',
  'ytd-segmented-like-dislike-button-renderer',
  '#owner-sub-count',
  '#subscriber-count',
  '#subscribers',
  'ytd-video-description-header-renderer #subscriber-count',
  'ytd-video-description-header-renderer #subscribers',
  'yt-content-metadata-view-model',
  '#channel-stats',
  'ytd-channel-about-stats-renderer',
  'ytd-channel-renderer #subscribers',
  'ytd-channel-renderer #video-count',
  'ytd-notification-topbar-button-renderer',
  '#notification-button',
  'ytd-feed-filter-chip-bar-renderer',
];

// Directly set inline styles on engagement elements. This works regardless of
// YouTube's CSP (no <style> injection) and regardless of shadow DOM (we use
// querySelectorAll which reaches Polymer light-DOM templates).
let engagementsTimer = null;
function applyEngagementsDom() {
  const on = hideEngagements && enabled;
  for (const sel of ENGAGEMENT_SELS) {
    document.querySelectorAll(sel).forEach(el => {
      if (on) el.style.setProperty('display', 'none', 'important');
      else    el.style.removeProperty('display');
    });
  }

  // Subscriber counts show up in many element types/ids across YouTube versions —
  // the owner renderer, the description header, the structured-description channel
  // card (the one with the channel's video list + social links), assorted
  // view-models — too many to enumerate as selectors, and the description-card one
  // has no #owner-sub-count/#subscribers id so the rules above miss it. Robust
  // catch-all: inside the watch-page owner/description/channel areas, hide any leaf
  // element whose OWN text is exactly a subscriber count ("1.38M subscribers"). Tag
  // what we hide so the toggle can reveal it again.
  const SUB_RE = /^\d[\d.,]*\s*[KMB]?\s+subscribers?$/i;
  if (on) {
    document.querySelectorAll(
      'ytd-video-owner-renderer, ytd-video-description-header-renderer, ' +
      'ytd-structured-description-content-renderer, ytd-watch-metadata, ' +
      'ytd-engagement-panel-section-list-renderer, ytd-channel-renderer'
    ).forEach(scope => {
      scope.querySelectorAll('*').forEach(node => {
        if (node.childElementCount <= 1 && SUB_RE.test(node.textContent?.trim() ?? '')) {
          node.style.setProperty('display', 'none', 'important');
          node.dataset.ytlfSubhidden = '1';
        }
      });
    });
  } else {
    document.querySelectorAll('[data-ytlf-subhidden]').forEach(node => {
      node.style.removeProperty('display');
      delete node.dataset.ytlfSubhidden;
    });
  }

  // Watch page: hide everything rendered after ytd-watch-metadata (comments etc.)
  document.querySelectorAll('ytd-watch-metadata').forEach(meta => {
    let sib = meta.nextElementSibling;
    while (sib) {
      if (on) sib.style.setProperty('display', 'none', 'important');
      else    sib.style.removeProperty('display');
      sib = sib.nextElementSibling;
    }
  });
}

function applyDisplayToggles() {
  if (!enabled) {
    document.body?.classList.remove(
      'ytlf-hide-home', 'ytlf-hide-sidebar', 'ytlf-hide-shorts',
      'ytlf-hide-playables', 'ytlf-hide-engagements'
    );
    applyEngagementsDom();
    return;
  }
  document.body?.classList.toggle('ytlf-hide-home',        hideHome);
  document.body?.classList.toggle('ytlf-hide-sidebar',     hideSidebar);
  document.body?.classList.toggle('ytlf-hide-shorts',      hideShorts);
  document.body?.classList.add('ytlf-hide-playables');
  document.body?.classList.toggle('ytlf-hide-engagements', hideEngagements);
  applyEngagementsDom();
  if (hideShorts) tagShorts();
  tagPlayables();
}

// --- Language helpers ---

function getLang() { return localStorage.getItem(LANG_KEY) ?? ''; }
function setLang(code) {
  localStorage.setItem(LANG_KEY, code);
  // A stored translation is only valid for the language it was made for. Keep the
  // original query (ORIG_QUERY_KEY) so switching language re-translates from the
  // user's original text, never from a prior translation.
  sessionStorage.removeItem(LAST_TRANSLATED_KEY);
}

// --- Theme ---

function ytIsDark() { return document.documentElement.hasAttribute('dark'); }

function resolveTheme() {
  return localStorage.getItem(THEME_KEY) ?? (ytIsDark() ? 'dark' : 'light');
}

function applyTheme(widget, theme) {
  widget.dataset.theme = theme;
  const btn = widget.querySelector('#ytlf-toggle');
  if (btn) btn.textContent = theme === 'dark' ? '☀' : '🌙';
}

// Follow YouTube's own theme switch when the user hasn't picked one manually
new MutationObserver(() => {
  if (localStorage.getItem(THEME_KEY)) return;
  const w = document.getElementById('ytlf');
  if (w) applyTheme(w, ytIsDark() ? 'dark' : 'light');
}).observe(document.documentElement, { attributes: true, attributeFilter: ['dark'] });

// YouTube API returns BCP-47 (e.g. "zh-Hans", "en-US"). Normalise to our codes.
function normaliseApiLang(lang) {
  if (!lang) return null;
  if (lang.startsWith('zh-Hans')) return 'zh-CN';
  if (lang.startsWith('zh-Hant')) return 'zh-TW';
  return lang.split('-')[0];
}

function isApiMatch(apiLang, selected) {
  const n = normaliseApiLang(apiLang);
  return n === selected || (n === 'zh' && (selected === 'zh-CN' || selected === 'zh-TW'));
}

// CLD returns 'zh' for both Simplified and Traditional.
function isCldMatch(detected, selected) {
  return detected === selected ||
    (detected === 'zh' && (selected === 'zh-CN' || selected === 'zh-TW'));
}

// Returns false when the extension has been reloaded and this content script
// is now an orphan — chrome APIs are gone but the script is still running.
function isContextValid() {
  try { return !!chrome.runtime?.id; }
  catch { return false; }
}

// Pages where we actively filter renderers.
// Personal pages (/feed/you, /feed/history, /feed/library, etc.) are excluded —
// filtering your own playlists and history by language makes no sense.
function isFilteredPage() {
  const p = window.location.pathname;
  return p === '/results' ||
         p === '/watch'   ||
         p === '/'        ||
         p === '/feed/subscriptions' ||
         p === '/feed/trending';
}

// --- Badge language: read YouTube's own language indicator from the video card ---
// YouTube renders a language badge (e.g. "English", "Dutch") directly in the DOM
// for videos that have language metadata set. This is more accurate than CLD because
// it reflects the actual audio language, not just the title text.

// Build a lookup: lowercase label → code  (e.g. "dutch" → "nl")
const LABEL_TO_CODE = Object.fromEntries(
  LANGUAGES.filter(l => l.code).map(l => [l.label.toLowerCase(), l.code])
);

function getBadgeLangCode(renderer) {
  // Try the selectors YouTube has used across versions, newest first.
  // We use our LANGUAGES list as an allowlist so we never mistake "4K" / "CC" for a language.
  const els = renderer.querySelectorAll(
    '.badge-shape-wiz__text, ' +               // YouTube ≥ 2024
    'ytd-badge-supported-renderer span, ' +    // mid-era
    'ytd-badge-supported-renderer p'           // older
  );
  for (const el of els) {
    const code = LABEL_TO_CODE[el.textContent.trim().toLowerCase()];
    if (code) return code;
  }
  return null; // no language badge found on this card
}

// --- Text detection (used when no API key, or when creator hasn't set a language) ---

function filterByText(renderer, id = null) {
  if (!isContextValid()) { setDisplay(renderer, ''); return; }

  const lang = getLang(); // capture for async callback

  // 1. Try YouTube's own badge — handles "Dutch title, English video" correctly.
  const badgeCode = getBadgeLangCode(renderer);
  if (badgeCode !== null) {
    decide(renderer, (badgeCode === lang) ? '' : 'none', id);
    return;
  }

  // 2. No badge present — fall back to CLD on title + snippet text.
  const title   = renderer.querySelector('#video-title')?.textContent?.trim() ?? '';
  const snippet = renderer.querySelector('#description-text')?.textContent?.trim() ?? '';
  const text    = title.length >= MIN_TEXT_LEN ? title : `${title} ${snippet}`.trim();
  // No text to detect (music videos, symbol-only titles) — show, never strand hidden.
  if (!text) { decide(renderer, '', id); return; }

  try {
    chrome.i18n.detectLanguage(text, ({ languages }) => {
      if (!enabled) { decide(renderer, '', id); return; }
      const top = languages?.[0];
      // Renderer was pre-hidden by queueRenderer. Uncertain = show (benefit of doubt).
      const display = (!top || top.percentage < MIN_CONF || isCldMatch(top.language, lang))
        ? '' : 'none';
      decide(renderer, display, id);
    });
  } catch {
    setDisplay(renderer, ''); // context gone mid-call — reveal rather than hide
  }
}

// --- YouTube API: videos.list, 1 unit per call, batched up to 50 IDs ---

async function fetchMetadata(ids) {
  const url = new URL('https://www.googleapis.com/youtube/v3/videos');
  url.searchParams.set('part',   'snippet');
  url.searchParams.set('id',     ids.join(','));
  url.searchParams.set('fields', 'items(id,snippet(defaultLanguage,defaultAudioLanguage))');
  url.searchParams.set('key',    cachedApiKey);
  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`YouTube API ${res.status}`);
  return res.json();
}

// --- Translation via Google Translate (no key required) ---

async function translateQuery(text, targetLang) {
  const url = new URL('https://translate.googleapis.com/translate_a/single');
  url.searchParams.set('client', 'gtx');
  url.searchParams.set('sl', 'auto');       // auto-detect source language
  url.searchParams.set('tl', targetLang);   // our codes match Google's (zh-CN, zh-TW, etc.)
  url.searchParams.set('dt', 't');
  url.searchParams.set('q', text);
  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`translate ${res.status}`);
  const data = await res.json();
  // Response: [[[translatedChunk, original], ...], ...]
  return data[0].map(chunk => chunk[0]).join('');
}

function getVideoId(renderer) {
  const a = renderer.querySelector('a#video-title');
  if (!a?.href) return null;
  try { return new URL(a.href).searchParams.get('v'); }
  catch { return null; }
}

// Write style.display only when it actually changes — redundant writes retrigger
// MutationObservers (ours and other extensions') for no reason.
function setDisplay(el, value) {
  if (el.style.display !== value) el.style.display = value;
}

// --- Decision cache ---
// videoId → display value ('' = show, 'none' = hide), valid for decidedLang.
// YouTube re-renders the results list in several waves per page load; without
// this cache every wave re-hides all renderers and re-detects from scratch,
// which the user sees as the whole page blanking and reloading repeatedly.
// A decision is language-specific and video-specific, so it stays valid
// across navigations and re-renders until the user picks another language.

const decided = new Map();
let decidedLang = null;

// Per-NODE memory of the last FINAL decision applied to a renderer element
// (keyed by the DOM node, not the video id). When YouTube re-stamps/recycles a
// result card, its <a#video-title> anchor transiently detaches, so getVideoId()
// returns null for a moment. Without this, queueRenderer would hide a card that
// is currently visible — then show it again when the anchor rebinds — producing
// the "videos appear then disappear over and over" churn. A node that already
// has a final decision re-asserts it instead of blanking. Reset on language
// change because a node's correct decision depends on the selected language.
let nodeDecision = new WeakMap();

function getDecision(id) {
  const lang = getLang();
  if (decidedLang !== lang) { decided.clear(); nodeDecision = new WeakMap(); decidedLang = lang; }
  return decided.get(id);
}

function setDecision(id, display) {
  if (id) decided.set(id, display);
}

// Apply a FINAL decision to a renderer: remember it by node, cache it by id,
// and set the display. Provisional pre-hides (undecided) must NOT go through
// here — only genuine decisions, so a transient null id never re-asserts a
// provisional "none".
function decide(renderer, display, id) {
  nodeDecision.set(renderer, display);
  if (id) setDecision(id, display);
  setDisplay(renderer, display);
}

// No veil. Earlier versions hid the whole results container (ytd-page-manager)
// while decisions computed, then revealed once. On real YouTube that container
// is re-rendered continuously during a results load, so the veil never settled,
// blanked the page for seconds, and its visibility toggling made YouTube
// re-stamp the list — a feedback storm. Correctness now comes entirely from the
// per-node decision memory (a decided card can never be un-decided), so each
// card simply appears once when its decision lands and never flickers. No global
// hide, no settle timers, no feedback surface.

// --- Batch queue ---

const pending = new Map(); // videoId → Set<Element>
let flushTimer = null;

function scheduleFlush() {
  // Do NOT reset an already-pending flush. YouTube re-stamps undecided cards
  // continuously, and resetting on every re-stamp kept pushing the flush back,
  // so cards stayed hidden for ~1s before being decided. Fire once, promptly.
  if (flushTimer) return;
  flushTimer = setTimeout(() => { flushTimer = null; flush(); }, BATCH_MS);
}

async function flush() {
  if (!enabled) { pending.clear(); return; }
  const lang = getLang();
  if (!lang || pending.size === 0) { pending.clear(); return; }

  const batch = new Map(pending);
  pending.clear();
  ytlfLog(`flush: deciding ${batch.size} videos (apiKey=${!!cachedApiKey})`);
  await decideBatch(batch, lang);
}

async function decideBatch(batch, lang) {
  // No API key: text detection for everything in this batch
  if (!cachedApiKey) {
    for (const [id, renderers] of batch) renderers.forEach(r => filterByText(r, id));
    return;
  }

  // Split into chunks of 50 (API limit per request)
  const ids = [...batch.keys()];
  for (let i = 0; i < ids.length; i += 50) {
    const chunk = ids.slice(i, i + 50);
    try {
      const data     = await fetchMetadata(chunk);
      const returned = new Set();

      for (const item of (data.items ?? [])) {
        returned.add(item.id);
        // defaultAudioLanguage = the original audio track language (excludes AI dubs)
        const apiLang   = item.snippet.defaultAudioLanguage || item.snippet.defaultLanguage;
        const renderers = batch.get(item.id) ?? new Set();

        if (!enabled) {
          renderers.forEach(r => setDisplay(r, ''));
        } else if (!apiLang) {
          // Creator never set a language — text detection is the best we can do
          renderers.forEach(r => filterByText(r, item.id));
        } else {
          const display = isApiMatch(apiLang, lang) ? '' : 'none';
          renderers.forEach(r => decide(r, display, item.id));
        }
      }

      // IDs the API didn't return (private, deleted, embargoed)
      for (const [id, renderers] of batch) {
        if (!returned.has(id)) {
          if (!enabled) renderers.forEach(r => setDisplay(r, ''));
          else renderers.forEach(r => filterByText(r, id));
        }
      }
    } catch {
      // API error: fall back to text detection for this chunk only
      for (const id of chunk) (batch.get(id) ?? new Set()).forEach(r => filterByText(r, id));
    }
  }
}

// --- Main entry point per renderer ---

function queueRenderer(renderer) {
  const lang = getLang();
  if (!lang || !enabled) { setDisplay(renderer, ''); return; }

  const id = getVideoId(renderer);

  // Transient re-stamp/recycle: the <a#video-title> anchor briefly detaches, so
  // getVideoId() is momentarily null. If this exact node already has a final
  // decision, re-assert it rather than blanking a card that is currently shown.
  // This is THE fix for the appear/disappear churn — it makes a transient null
  // id incapable of un-deciding a settled node.
  if (id === null) {
    const remembered = nodeDecision.get(renderer);
    if (remembered !== undefined) { setDisplay(renderer, remembered); return; }
  }

  if (!id) {
    // Playlist cards have no video ID and no audio language — always show them.
    if (renderer.querySelector('a[href*="/playlist?"]')) {
      decide(renderer, '');
      return;
    }
    // Unhydrated shell — wait for the title/link to bind; the observer requeues
    // it then. Leave it VISIBLE (never hide undecided content) so the page does
    // not collapse to empty.
    if (!renderer.querySelector('#video-title')) return;
    // No video id but has a title → text detection decides (and hides only if
    // it confirms a non-matching language). Not pre-hidden.
    filterByText(renderer);
    return;
  }

  // Already decided for this video + language — apply instantly, no blink.
  const cached = getDecision(id);
  if (cached !== undefined) { decide(renderer, cached, id); return; }

  // Undecided: DO NOT pre-hide. Pre-hiding every card emptied the results list,
  // which made YouTube's infinite scroll fire continuously (load more → hide →
  // empty → load more) — the "results keep refreshing" the user saw. Leaving
  // cards visible keeps the list full; flush() hides only the confirmed
  // non-matching ones. A non-matching card may flash briefly, then hide once.
  if (!pending.has(id)) pending.set(id, new Set());
  pending.get(id).add(renderer);
  scheduleFlush();
}

function filterAll() {
  pending.clear();
  clearTimeout(flushTimer); flushTimer = null;
  const renderers = document.querySelectorAll(RENDERER_SEL);
  renderers.forEach(queueRenderer);
  ytlfLog(`filterAll: ${renderers.length} renderers, ${decided.size} cached, ${pending.size} pending`);
  if (pending.size > 0) scheduleFlush();
}

// --- Widget ---

function buildWidget() {
  const wrapper = document.createElement('div');
  wrapper.id = 'ytlf';
  wrapper.dataset.enabled = enabled ? '1' : '0';

  // ── Custom dropdown ──────────────────────────────────────
  const dropdown = document.createElement('div');
  dropdown.id = 'ytlf-dropdown';

  const trigger = document.createElement('button');
  trigger.id = 'ytlf-trigger';
  trigger.title = `YouTube Language Filter v${chrome.runtime.getManifest().version}`;
  trigger.setAttribute('aria-haspopup', 'listbox');
  trigger.setAttribute('aria-expanded', 'false');

  const triggerLabel = document.createElement('span');
  triggerLabel.id = 'ytlf-trigger-label';

  const triggerArrow = document.createElement('span');
  triggerArrow.id = 'ytlf-trigger-arrow';
  triggerArrow.innerHTML =
    '<svg width="10" height="6" viewBox="0 0 10 6" fill="none">' +
    '<path d="M1 1l4 4 4-4" stroke="currentColor" stroke-width="1.5"' +
    ' stroke-linecap="round" stroke-linejoin="round"/></svg>';

  trigger.appendChild(triggerLabel);
  trigger.appendChild(triggerArrow);

  const panel = document.createElement('div');
  panel.id = 'ytlf-panel';
  panel.setAttribute('role', 'listbox');

  // ── Search bar: type to filter, Enter selects the highlighted match ──
  const search = document.createElement('input');
  search.id = 'ytlf-search';
  search.type = 'text';
  search.placeholder = 'Search languages…';
  search.autocomplete = 'off';
  search.spellcheck = false;
  panel.appendChild(search);

  for (const { code, label } of LANGUAGES) {
    const opt = document.createElement('div');
    opt.className = 'ytlf-opt';
    opt.setAttribute('role', 'option');
    opt.dataset.value = code;
    opt.textContent = label;
    panel.appendChild(opt);
  }

  dropdown.appendChild(trigger);
  dropdown.appendChild(panel);

  let activeOpt = null; // keyboard-highlighted option

  function visibleOpts() {
    return [...panel.querySelectorAll('.ytlf-opt')].filter(o => o.style.display !== 'none');
  }

  function setActive(opt) {
    panel.querySelectorAll('.ytlf-opt.active').forEach(o => o.classList.remove('active'));
    activeOpt = opt ?? null;
    if (activeOpt) {
      activeOpt.classList.add('active');
      activeOpt.scrollIntoView({ block: 'nearest' });
    }
  }

  // Filter options by the search text. Highlight the best match:
  // a label starting with the text beats one merely containing it.
  function applyFilter() {
    const q = search.value.trim().toLowerCase();
    let firstPrefix = null, firstMatch = null;
    panel.querySelectorAll('.ytlf-opt').forEach(o => {
      const label = o.textContent.toLowerCase();
      const match = !q || label.includes(q);
      o.style.display = match ? '' : 'none';
      if (match && !firstMatch) firstMatch = o;
      if (match && q && !firstPrefix && label.startsWith(q)) firstPrefix = o;
    });
    setActive(q ? (firstPrefix ?? firstMatch) : null);
  }

  search.addEventListener('input', applyFilter);
  search.addEventListener('keydown', (e) => {
    e.stopPropagation(); // keep keystrokes away from YouTube's hotkeys
    if (e.key === 'Enter') {
      const target = activeOpt ?? visibleOpts()[0];
      if (target) target.click(); // runs the full select → translate → search flow
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const opts = visibleOpts();
      if (!opts.length) return;
      const i = opts.indexOf(activeOpt);
      setActive(e.key === 'ArrowDown'
        ? opts[Math.min(i + 1, opts.length - 1)]
        : opts[Math.max(i - 1, 0)]);
    } else if (e.key === 'Escape') {
      closePanel();
    }
  });

  // Sync label + selected highlight to current getLang()
  function syncSelected() {
    const lang = getLang();
    triggerLabel.textContent = LANGUAGES.find(l => l.code === lang)?.label ?? 'All Languages';
    panel.querySelectorAll('.ytlf-opt').forEach(o =>
      o.classList.toggle('selected', o.dataset.value === lang)
    );
  }

  function openPanel() {
    panel.classList.add('open');
    trigger.setAttribute('aria-expanded', 'true');
    search.value = '';
    applyFilter();
    search.focus();
    panel.querySelector('.ytlf-opt.selected')?.scrollIntoView({ block: 'nearest' });
  }
  function closePanel() {
    panel.classList.remove('open');
    trigger.setAttribute('aria-expanded', 'false');
  }

  let ddBusy = false; // prevent double-fire during translation

  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    if (ddBusy) return;
    panel.classList.contains('open') ? closePanel() : openPanel();
  });

  panel.addEventListener('click', async (e) => {
    e.stopPropagation(); // clicks inside the panel (e.g. the search box) must not close it
    const opt = e.target.closest('.ytlf-opt');
    if (!opt || ddBusy) return;
    const newLang = opt.dataset.value;
    setLang(newLang);
    syncSelected();
    closePanel();

    // Switching language automatically re-runs the search: translate the user's
    // ORIGINAL query into the new language and navigate once. The user never has
    // to also press Search. We always translate from the original text (never a
    // prior translation), on both the results page and a watch page reached from
    // a search. "All Languages" (newLang === '') skips this and just unfilters.
    if (newLang && (location.pathname === '/results' || location.pathname === '/watch')) {
      const original = getOriginalQuery() || (
        location.pathname === '/results'
          ? (new URL(location.href).searchParams.get('search_query') ?? '')
          : (document.querySelector('input[name="search_query"], input#search')?.value.trim() ?? '')
      );
      if (original) {
        ddBusy = true;
        wrapper.style.opacity = '0.5';
        try {
          if (await translateAndNavigate(original, newLang)) return;
        } finally { ddBusy = false; wrapper.style.opacity = ''; }
      }
    }
    filterAll();
  });

  // Close when clicking anywhere outside the dropdown
  document.addEventListener('click', closePanel);

  syncSelected();

  // ── Light / dark toggle ──────────────────────────────────
  const toggle = document.createElement('button');
  toggle.id = 'ytlf-toggle';
  toggle.title = 'Toggle light / dark';
  toggle.addEventListener('click', () => {
    const next = wrapper.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(wrapper, next);
  });

  wrapper.appendChild(dropdown);
  wrapper.appendChild(toggle);

  applyTheme(wrapper, resolveTheme());
  return wrapper;
}

let widgetRetryCount = 0;
function injectWidget() {
  const existing = document.getElementById('ytlf');
  if (existing) {
    existing.dataset.enabled = enabled ? '1' : '0';
    widgetRetryCount = 0;
    return;
  }
  const center = document.querySelector('#center');
  if (!center) {
    // #center not ready yet (e.g. extension enabled on already-open tab) — retry
    if (widgetRetryCount++ < 10) setTimeout(injectWidget, 300);
    return;
  }
  widgetRetryCount = 0;
  center.appendChild(buildWidget());
}

// --- MutationObserver: catches renderers added by infinite scroll ---

const observer = new MutationObserver((mutations) => {
  if (!isContextValid()) { observer.disconnect(); return; }
  if (!enabled) return; // extension off — do absolutely nothing

  // Shorts/Playables scanner — debounced to avoid thrashing
  if (hideShorts || enabled) {
    clearTimeout(shortsTagTimer);
    shortsTagTimer = setTimeout(() => {
      if (hideShorts) tagShorts();
      if (enabled)    tagPlayables();
    }, 150);
  }

  // Re-apply engagement hiding to newly added elements (infinite scroll, SPA loads)
  if (hideEngagements && enabled) {
    clearTimeout(engagementsTimer);
    engagementsTimer = setTimeout(applyEngagementsDom, 150);
  }

  if (!getLang() || !isFilteredPage()) return;
  // Collect the unique renderers touched by this mutation batch, then process
  // each ONCE. YouTube streams many descendant nodes (thumbnails, badges,
  // metadata) into the same card; without de-duping we'd call queueRenderer
  // dozens of times per card per batch — the "observer queued 161 renderers"
  // storm. A Set collapses that to one call per affected card.
  const touched = new Set();
  for (const { addedNodes } of mutations) {
    for (const node of addedNodes) {
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      if (node.matches(RENDERER_SEL)) {
        touched.add(node);
      } else {
        node.querySelectorAll(RENDERER_SEL).forEach(r => touched.add(r));
        // Data bound INTO an existing renderer (Polymer hydration / recycling):
        // requeue the host so shells get decided once their title binds.
        const host = node.closest(RENDERER_SEL);
        if (host) touched.add(host);
      }
    }
  }
  touched.forEach(queueRenderer);
});

// --- Force original audio track when language filter is active ---

// Returns 'stop' when done (or nothing to do), 'retry' when tracks aren't ready yet.
// Strategy: ONLY select tracks that YouTube explicitly labels "original"
// (e.g. "Russian original", "Italian original"). Never infer from absence of "dubbed" —
// that incorrectly matches auto-dubbed tracks like "English (US)" whose displayName
// contains no "dubbed" text, causing the extension to actively select the wrong track.
function switchToOriginalAudio() {
  if (!isContextValid()) return 'stop';
  if (window.location.pathname !== '/watch') return 'stop';

  const player = document.querySelector('#movie_player');
  if (typeof player?.getAvailableAudioTracks !== 'function') return 'retry';

  const tracks = player.getAvailableAudioTracks();
  if (!tracks?.length) return 'retry';

  // Find a track explicitly labeled "original" by YouTube
  const original = tracks.find(t => (t.displayName ?? '').toLowerCase().includes('original'));

  if (!original) {
    // Single track with no "original" label → YouTube may still be loading tracks
    // Multiple tracks with no "original" label → single-language video, nothing to do
    return tracks.length === 1 ? 'retry' : 'stop';
  }

  if (typeof player.setAudioTrack === 'function') {
    player.setAudioTrack(original);
  }
  return 'stop';
}

// Single timer — prevents multiple concurrent retry chains from piling up
// when yt-page-data-updated fires several times during page load.
let audioTimer = null;

// Faster early retries to catch the track before YouTube auto-selects dubbed audio.
const AUDIO_RETRY_MS = [100, 200, 300, 500, 1000, 1000, 1500, 2000, 2000, 2000];

function scheduleAudioSwitch(attempt = 0) {
  if (!isContextValid()) return;
  if (!enabled) return; // extension off — leave the audio track alone
  if (window.location.pathname !== '/watch') return;
  if (attempt >= AUDIO_RETRY_MS.length) return;

  if (switchToOriginalAudio() === 'retry') {
    clearTimeout(audioTimer);
    audioTimer = setTimeout(() => scheduleAudioSwitch(attempt + 1), AUDIO_RETRY_MS[attempt]);
  }
}

// Re-run on every YouTube data update — audio switch + early Shorts/Playables tagging
// (yt-page-data-updated fires before yt-navigate-finish, so tagging here reduces flash)
document.addEventListener('yt-page-data-updated', () => {
  if (!enabled) return; // extension off — do nothing
  scheduleAudioSwitch(0);
  if (hideShorts) tagShorts();
  tagPlayables();
});

// --- Search query language enforcement ---
//
// The extension guarantees the user only ever sees results in the selected
// language by translating the query BEFORE YouTube navigates. The search submit
// is intercepted (Enter / search button), the query is translated, and we
// navigate exactly once to the translated query — so no untranslated results
// ever render and there is no second "redirect" page load. ensureQueryInLang()
// is only a fallback for the rare submit paths we can't intercept (autocomplete
// click, voice search, a hand-edited URL).

const ORIG_QUERY_KEY      = 'ytlf_orig_query';      // the user's untranslated query
const LAST_TRANSLATED_KEY = 'ytlf_last_translated'; // the translated query we navigated to

function getOriginalQuery() {
  return sessionStorage.getItem(ORIG_QUERY_KEY) || null;
}

// Resolve true when CLD is confident `text` is already in `lang`, so translation
// (and the navigation it would cause) can be skipped.
function isInLang(text, lang) {
  return new Promise(resolve => {
    if (!isContextValid()) { resolve(false); return; }
    try {
      chrome.i18n.detectLanguage(text, ({ languages }) => {
        const top = languages?.[0];
        resolve(!!(top && top.percentage >= MIN_CONF && isCldMatch(top.language, lang)));
      });
    } catch { resolve(false); }
  });
}

// One navigation at a time — stops the dropdown change and the init() debounce
// from both firing location.assign for the same submit.
let navigating = false;

// Translate `original` into `lang` (skipping translation when it is already in
// that language) and navigate ONCE to /results for the final query. Persists the
// original->translated mapping so the page we land on recognises the query as
// already translated and never translates it again — which is what prevents the
// old double-navigate loop. Returns true if it navigated away (caller must stop).
async function translateAndNavigate(original, lang) {
  original = (original || '').trim();
  if (!original) return false;
  if (navigating) return true;

  let target = original;
  if (lang && !(await isInLang(original, lang))) {
    try {
      const t = (await translateQuery(original, lang)).trim();
      // Ignore trivial differences (capitalisation/punctuation) so we don't
      // reload to an essentially identical query.
      if (t && t.toLowerCase() !== original.toLowerCase()) target = t;
    } catch { /* translation failed — search the original query instead */ }
  }

  sessionStorage.setItem(ORIG_QUERY_KEY, original);
  sessionStorage.setItem(LAST_TRANSLATED_KEY, target);

  const cur = new URL(location.href);
  if (cur.pathname === '/results' &&
      cur.searchParams.get('search_query') === target) {
    return false; // already exactly here — nothing to navigate; caller filters
  }

  const url = new URL('/results', location.origin);
  url.searchParams.set('search_query', target);
  ytlfLog(`NAVIGATE: "${original}" -> "${target}" (${lang || 'all'})`);
  navigating = true;
  window.location.assign(url.toString());
  return true;
}

// Fallback for a /results load whose query slipped through untranslated
// (autocomplete click, voice search, hand-edited URL). Returns true if it
// navigated (caller must not filter yet).
async function ensureQueryInLang(lang) {
  const query = new URL(location.href).searchParams.get('search_query') ?? '';
  if (!query) return false;
  // We navigated here ourselves with an already-translated query — don't redo it.
  if (query === sessionStorage.getItem(LAST_TRANSLATED_KEY)) {
    ytlfLog('ensureQuery: already on translated page');
    return false;
  }
  return await translateAndNavigate(query, lang);
}

// --- Intercept the search submission so translation happens BEFORE navigation ---
// This is what removes the flash of untranslated results and the second page
// load: we stop YouTube's own navigation, translate, then navigate once. Enter is
// the version-independent path; the button selectors are best-effort. Anything
// not caught here still lands correctly via ensureQueryInLang() on init.

function searchInputEl() {
  return document.querySelector(
    'input#search, input[name="search_query"], ytd-searchbox input, yt-searchbox input'
  );
}

function isSearchInput(el) {
  return !!el && el.tagName === 'INPUT' &&
    (el.id === 'search' || el.name === 'search_query' ||
     !!el.closest('ytd-searchbox, yt-searchbox, #search-form'));
}

async function interceptSubmit(e, query) {
  // Stop YouTube's navigation synchronously, before any untranslated load starts.
  e.preventDefault();
  e.stopImmediatePropagation();
  if (!(await translateAndNavigate(query, getLang())) && isFilteredPage()) {
    filterAll(); // already on this exact query in this language — just re-filter
  }
}

// Enter pressed inside the search box.
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter' || e.isComposing || e.keyCode === 229) return;
  if (!enabled || !getLang()) return;            // All Languages → normal search
  if (!isSearchInput(e.target)) return;
  const query = e.target.value.trim();
  if (!query) return;
  interceptSubmit(e, query);
}, true);

// Click on the magnifying-glass search button (classic + current search boxes).
document.addEventListener('click', (e) => {
  if (!enabled || !getLang()) return;
  const btn = e.target.closest('#search-icon-legacy, .ytSearchboxComponentSearchButton');
  if (!btn) return;
  const query = (searchInputEl()?.value ?? '').trim();
  if (!query) return;
  interceptSubmit(e, query);
}, true);

// --- init ---

async function init() {
  ytlfLog(`init @ ${location.href}`);
  injectWidget();
  applyDisplayToggles();

  if (!enabled) {
    document.querySelectorAll(RENDERER_SEL).forEach(r => { r.style.display = ''; });
    return;
  }

  // On the results page, ensure the query matches the selected language before filtering.
  if (window.location.pathname === '/results') {
    const lang = getLang();
    if (lang && await ensureQueryInLang(lang)) return; // redirecting — don't filter yet
  }

  if (isFilteredPage()) filterAll();
  if (window.location.pathname === '/watch') scheduleAudioSwitch();
}

// Re-apply body classes the moment navigation starts so CSS takes effect before
// the new page content is rendered (prevents Shorts flash-of-content).
document.addEventListener('yt-navigate-start', () => {
  ytlfLog(`yt-navigate-start @ ${location.href}`);
  applyDisplayToggles();
});

// Debounce yt-navigate-finish: YouTube fires it multiple times per navigation.
// Without debouncing, concurrent init() calls both run ensureQueryInLang,
// both translate the query, and both call location.assign → infinite loop.
let initTimer = null;
document.addEventListener('yt-navigate-finish', () => {
  ytlfLog(`yt-navigate-finish @ ${location.href}`);
  clearTimeout(initTimer);
  initTimer = setTimeout(init, 50);
});
observer.observe(document.body, { childList: true, subtree: true });
init();
